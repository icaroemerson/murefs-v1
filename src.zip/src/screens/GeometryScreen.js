import React, { useEffect } from 'react';
import { ScrollView, StyleSheet } from 'react-native';
import { Card, Title, TextInput, HelperText, Checkbox } from 'react-native-paper';
import { useProject } from '../state/ProjectContext';
import WallDrawing from '../components/project/WallDrawing';

const GeometryScreen = () => {
  const {
    wallHeight, setWallHeight, elevation, setElevation,
    baseLength, setBaseLength, stemWidth, setStemWidth,
    toeWidth, setToeWidth, heelWidth, setHeelWidth,
    hasPassiveSoil, setHasPassiveSoil,
  } = useProject();

  useEffect(() => {
    const h = parseFloat(wallHeight);
    if (!isNaN(h) && h > 0) {
      const calculatedStemWidth = 0.08 * h;
      const calculatedBaseLength = 0.5 * h;
      const calculatedToeWidth = h / 6;
      const calculatedHeelWidth = calculatedBaseLength - calculatedToeWidth - calculatedStemWidth;
      
      setStemWidth(calculatedStemWidth.toFixed(2));
      setBaseLength(calculatedBaseLength.toFixed(2));
      setToeWidth(calculatedToeWidth.toFixed(2));
      setHeelWidth(calculatedHeelWidth.toFixed(2));
    } else {
      setStemWidth(''); setBaseLength('');
      setToeWidth(''); setHeelWidth('');
    }
  }, [wallHeight, setStemWidth, setBaseLength, setToeWidth, setHeelWidth]);

  return (
    <ScrollView style={styles.container}>
      {/* Card de Entradas Principais */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>Dimensões Principais (cm)</Title>
          <TextInput label="Altura do Muro (H)" value={wallHeight} onChangeText={setWallHeight} keyboardType="numeric" style={styles.input} mode="outlined" />
          <TextInput label="Elevação acima do aterro" value={elevation} onChangeText={setElevation} keyboardType="numeric" style={styles.input} mode="outlined" />
          
          <Checkbox.Item
            label="Considerar Empuxo Passivo"
            status={hasPassiveSoil ? 'checked' : 'unchecked'}
            onPress={() => setHasPassiveSoil(!hasPassiveSoil)}
            style={{ marginTop: 10 }}
          />
        </Card.Content>
      </Card>

      {/* Card de Visualização Dinâmica */}
      <Card style={styles.card}>
        <Card.Content>
            <Title>Visualização da Geometria</Title>
            <WallDrawing
              showDimensions={true}
              showReinforcement={false}
            />
        </Card.Content>
      </Card>

      {/* Card para as dimensões editáveis */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>Dimensões da Seção (cm)</Title>
          <TextInput label="Largura da Parede (Constante)" value={stemWidth} onChangeText={setStemWidth} keyboardType="numeric" style={styles.input} mode="outlined" />
          <HelperText>Sugestão: 8% de H</HelperText>
          <TextInput label="Base Externa (Ponta)" value={toeWidth} onChangeText={setToeWidth} keyboardType="numeric" style={styles.input} mode="outlined" />
          <HelperText>Sugestão: H / 6</HelperText>
          <TextInput label="Base Interna (Calcanhar)" value={heelWidth} onChangeText={setHeelWidth} keyboardType="numeric" style={styles.input} mode="outlined" />
          <HelperText>Sugestão: 0.5*H - Ponta - Largura da Parede</HelperText>
        </Card.Content>
      </Card>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 10, backgroundColor: '#f5f5f5' },
  card: { marginBottom: 15 },
  input: { marginTop: 10 },
});

export default GeometryScreen;