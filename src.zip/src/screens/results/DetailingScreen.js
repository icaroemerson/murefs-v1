// src/screens/results/DetailingScreen.js
import React from 'react';
import { ScrollView, View, StyleSheet } from 'react-native';
import { Text, Divider } from 'react-native-paper';

export default function DetailingScreen() {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text variant="titleLarge">Detalhamento</Text>
      <Divider style={{ marginVertical: 12 }} />
      <Text>
        Aqui vamos mostrar o detalhamento com base nas tabelas (ábacos) que você criou.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
});
