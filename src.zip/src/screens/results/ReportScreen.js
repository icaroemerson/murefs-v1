// src/screens/results/ReportScreen.js
import React from 'react';
import { ScrollView } from 'react-native';
import { Text } from 'react-native-paper';

export default function ReportScreen() {
  return (
    <ScrollView contentContainerStyle={{ padding: 12 }}>
      <Text variant="titleMedium">Relatório (prévia)</Text>
      <Text style={{ marginTop: 6, opacity: 0.7 }}>
        Sumário de entradas e resultados para exportar/compartilhar.
      </Text>
    </ScrollView>
  );
}
