// src/screens/results/CalculationScreen.js
import React, { useMemo } from 'react';
import { View, StyleSheet } from 'react-native';
import { Text, Divider } from 'react-native-paper';
import { useProject } from '../../state/ProjectContext';
import { bearingCheck } from '../../core/checks/bearing';

export default function CalculationScreen() {
  const {
    baseLength,           // cm
    soilBearingCapacity,  // kPa
  } = useProject();

  // EXEMPLO: substitua pelos seus resultados reais
  // Esses valores normalmente vêm do núcleo de cálculo depois dos carregamentos:
  const PT =  // kN/m
    0;        // TODO: coloque aqui o peso total que você já calcula
  const MR =  // kN·cm/m
    0;        // TODO: seu momento resistente
  const MT =  // kN·cm/m
    0;        // TODO: seu momento de tombamento

  const bearing = useMemo(() => bearingCheck({
    PT,
    MR,
    MT,
    B_cm: baseLength,                 // largura da base em cm
    qa_adm: soilBearingCapacity,      // kPa
  }), [PT, MR, MT, baseLength, soilBearingCapacity]);

  return (
    <View style={styles.container}>
      <Text variant="titleLarge">Resultados</Text>

      {/* ... seus outros blocos de resultados ... */}

      <Divider style={{ marginVertical: 16 }} />
      <Text variant="titleMedium">Verificação de Fundação (Tensões)</Text>
      <Text>qₐ (adm.): {Number(bearing.qa_adm).toFixed(1)} kPa</Text>
      <Text>e = {bearing.e_m.toFixed(3)} m</Text>
      <Text>q̄ (média) = {bearing.q_avg.toFixed(1)} kPa</Text>
      <Text>q_max = {bearing.q_max.toFixed(1)} kPa</Text>
      <Text>q_min = {bearing.q_min.toFixed(1)} kPa</Text>
      <Text>Sem tração? {bearing.within_kernel ? 'Sim (e ≤ B/6)' : 'Não (e > B/6)'}</Text>
      <Text style={{ marginTop: 6, color: bearing.ok ? 'green' : 'crimson' }}>
        {bearing.ok ? 'OK: q_max ≤ qₐ' : 'NÃO OK: q_max > qₐ'}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16, gap: 6 },
});
