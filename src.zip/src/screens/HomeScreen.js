import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Button, Text } from 'react-native-paper';

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.c}>
      <Text variant="headlineSmall" style={{ marginBottom: 16 }}>
        Murefs — Muros de Arrimo perfil L
      </Text>
      <Button mode="contained" onPress={() => navigation.navigate('Inputs')}>
        Iniciar novo projeto
      </Button>
      <Button mode="text" style={{ marginTop: 8 }} onPress={() => navigation.navigate('Settings')}>
        Configurações
      </Button>
    </View>
  );
}

const styles = StyleSheet.create({
  c: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 16 },
});
