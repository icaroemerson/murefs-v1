// src/screens/inputs/LoadScreen.js
import React, { useMemo } from 'react';
import { ScrollView, View, StyleSheet } from 'react-native';
import { Text, Divider } from 'react-native-paper';
import { useProject } from '../../state/ProjectContext';
import { computeLoads } from '../../utils/calcLoads';

const fmt = (v, d = 2) => {
  if (!isFinite(v)) return '—';
  const p = Math.pow(10, d);
  return String(Math.round(v * p) / p).replace('.', ',');
};

const OK = ({ ok }) => (
  <Text style={{ fontWeight: '700', color: ok ? '#16a34a' : '#dc2626' }}>
    {ok ? 'OK' : 'NÃO'}
  </Text>
);

const Pair = ({ label, value, unit }) => (
  <View style={styles.row}>
    <Text style={styles.k}>{label}</Text>
    <Text style={styles.v}>
      {value}
      {unit ? ` ${unit}` : ''}
    </Text>
  </View>
);

export default function LoadScreen() {
  const ctx = useProject();

  // roda seus cálculos com o estado atual
  const result = useMemo(
    () => computeLoads(ctx),
    [
      ctx.H, ctx.tStem, ctx.bs, ctx.ds,
      ctx.soilGamma, ctx.soilPhi, ctx.soilQa,
      ctx.hasWaterTable, ctx.showPassive, ctx.hp, ctx.bp
    ]
  );

  const { weights, pressures, moments, foundation } = result || {};

  // Proteções contra undefined/NaN
  const qa    = foundation?.qa;
  const qmax  = foundation?.q_max;
  const qmin  = foundation?.q_min;
  const qm    = foundation?.q_m;
  const xcomp = foundation?.x_comp_cm;

  // largura da base B (cm) vem do contexto
  const B_cm = Number(ctx?.bs) || 0;
  const B2_cm = B_cm / 2;

  // Checagens separadas
  const geomOK = isFinite(B2_cm) && isFinite(xcomp) && B2_cm > xcomp;
  const capOK  = isFinite(qa) && isFinite(qmax) && qa >= qmax;

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text variant="titleLarge">Cargas / Resultados</Text>
      <Divider style={{ marginVertical: 12 }} />

      <Text variant="titleMedium" style={styles.section}>Pesos (kN/m)</Text>
      <Pair label="Peso da base" value={fmt(weights?.W_base)} />
      <Pair label="Peso da cortina" value={fmt(weights?.W_stem)} />
      <Pair label="Peso do solo (ativo)" value={fmt(weights?.W_soil_act)} />
      <Pair label="Peso total" value={fmt(weights?.W_tot)} />

      <Text variant="titleMedium" style={styles.section}>Empuxos (kN/m)</Text>
      <Pair label="Empuxo ativo Ea" value={fmt(pressures?.E_a)} />
      <Pair label="Empuxo passivo Ep" value={fmt(pressures?.E_p)} />

      <Text variant="titleMedium" style={styles.section}>Momentos (kN·cm/m)</Text>
      <Pair label="Momento resistente Mr" value={fmt(moments?.Mr)} />
      <Pair label="Momento de tombamento Mt" value={fmt(moments?.Mt)} />
      <View style={styles.row}>
        <Text style={styles.k}>FS (tombamento) = Mr / Mt</Text>
        <Text style={styles.v}>
          {fmt(result?.checks?.overturningFS)} <OK ok={(result?.checks?.overturningFS ?? 0) >= 2.0} />
        </Text>
      </View>

      <Text variant="titleMedium" style={styles.section}>Fundação</Text>
      <Pair label="Excentricidade e" value={fmt(foundation?.e, 1)} unit="cm" />
      <Pair label="q média" value={fmt(qm)} unit="kPa" />
      <Pair label="q máx" value={fmt(qmax)} unit="kPa" />
      <Pair label="q mín" value={fmt(qmin)} unit="kPa" />
      <Pair label="qa (admissível)" value={fmt(qa)} unit="kPa" />
      <Pair label="x (comp.)" value={fmt(xcomp, 1)} unit="cm" />
      <Pair label="B/2" value={fmt(B2_cm, 1)} unit="cm" />

      {/* OK 1: condição geométrica B/2 > x */}
      <View style={styles.row}>
        <Text style={styles.k}>Condição geométrica (B/2 &gt; x)</Text>
        <Text style={styles.v}><OK ok={!!geomOK} /></Text>
      </View>

      {/* OK 2: capacidade qa >= qmax */}
      <View style={styles.row}>
        <Text style={styles.k}>Capacidade (qa ≥ qmax)</Text>
        <Text style={styles.v}><OK ok={!!capOK} /></Text>
      </View>

      <Text variant="titleMedium" style={styles.section}>Deslizamento</Text>
      <View style={styles.row}>
        <Text style={styles.k}>FS (deslizamento)</Text>
        <Text style={styles.v}>
          {fmt(result?.checks?.slidingFS)} <OK ok={(result?.checks?.slidingFS ?? 0) >= 1.5} />
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16 },
  section: { marginTop: 16, marginBottom: 6 },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6 },
  k: { opacity: 0.75 },
  v: { fontWeight: '700' },
});
