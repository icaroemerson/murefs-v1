import React from 'react';
import { StyleSheet } from 'react-native';
import { TextInput, Card, Title } from 'react-native-paper';
import { ScrollView } from 'react-native-gesture-handler';

// Aba para inserir os dados dos Solos
const SoilScreen = () => {
  return (
    <ScrollView style={styles.container}>
      <Card style={styles.card}>
        <Card.Content>
          <Title>Solo de Reaterro</Title>
          <TextInput label="Peso Específico (γ) em kN/m³" keyboardType="numeric" style={styles.input} mode="outlined" />
          <TextInput label="Ângulo de Atrito (φ) em graus" keyboardType="numeric" style={styles.input} mode="outlined" />
          <TextInput label="Coesão (c) em kPa" keyboardType="numeric" style={styles.input} mode="outlined" />
        </Card.Content>
      </Card>
      <Card style={styles.card}>
        <Card.Content>
          <Title>Solo de Fundação</Title>
          <TextInput label="Peso Específico (γ) em kN/m³" keyboardType="numeric" style={styles.input} mode="outlined" />
          <TextInput label="Ângulo de Atrito (φ) em graus" keyboardType="numeric" style={styles.input} mode="outlined" />
          <TextInput label="Coesão (c) em kPa" keyboardType="numeric" style={styles.input} mode="outlined" />
          <TextInput label="Tensão Admissível (σ adm) em kPa" keyboardType="numeric" style={styles.input} mode="outlined" />
        </Card.Content>
      </Card>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 10, backgroundColor: '#f5f5f5' },
  card: { marginBottom: 15 },
  input: { marginTop: 10 },
});

export default SoilScreen;