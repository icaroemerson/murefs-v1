import React from 'react';
import { StyleSheet, ScrollView } from 'react-native';
import { TextInput, Card, Title, Button } from 'react-native-paper';
import { useNavigation } from '@react-navigation/native'; // <<-- NOVO IMPORT

// Aba para inserir as Sobrecargas e iniciar o cálculo
const LoadsScreen = () => {
  const navigation = useNavigation(); // <<-- HOOK PARA ACESSAR A NAVEGAÇÃO

  const handleCalculate = () => {
    console.log("Cálculo iniciado!");
    // Futuramente, passaremos os dados para a próxima tela
    navigation.navigate('Results'); // <<-- NAVEGA PARA A TELA DE RESULTADOS
  };

  return (
    <ScrollView style={styles.container}>
      <Card style={styles.card}>
        <Card.Content>
          <Title>Sobrecarga</Title>
          <TextInput
            label="Sobrecarga no reaterro (q) em kPa"
            keyboardType="numeric"
            style={styles.input}
            mode="outlined"
          />
        </Card.Content>
      </Card>
      <Button
        mode="contained"
        onPress={handleCalculate}
        style={styles.button}
      >
        Ver Resultados
      </Button>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 10, backgroundColor: '#f5f5f5' },
  card: { marginBottom: 15 },
  input: { marginTop: 10 },
  button: { marginTop: 20, padding: 8 },
});

export default LoadsScreen;